//Hosting https://manu.cicloflorenciopintado.es

const URLSERVER = "https://manu.cicloflorenciopintado.es/laravel/";
export const API_URL = URLSERVER+"public/"
export const IMAGE_URL = URLSERVER+"storage/app/public/photos/";

//Hosting Local
//const URLSERVER = "http://localhost:8000/";
//export const API_URL = URLSERVER;
//export const IMAGE_URL = URLSERVER+"storage/photos/";